from django.contrib import admin
from .models import Bazzar,Querys
# Register your models here.

admin.site.register(Bazzar)
admin.site.register(Querys)